import React, { useState, useEffect } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";

const Profile = () => {
  const [profile, setProfile] = useState({
    first_name: "",
    last_name: "",
    phone: "",
    default_address: "",
    default_city: "",
    default_state: "",
    default_pincode: "",
  });
  const navigate = useNavigate();

  useEffect(() => {
    axios.get("/api/profile/complete/").then((response) => {
      setProfile(response.data.profile);
    });
  }, []);

  const handleChange = (e) => {
    setProfile({ ...profile, [e.target.name]: e.target.value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    axios.post("/api/profile/complete/", profile)
      .then(() => {
        navigate("/dashboard");
      })
      .catch((error) => {
        console.error("Error updating profile", error);
      });
  };

  return (
    <div>
      <h2>Complete Your Profile</h2>
      <form onSubmit={handleSubmit}>
        <input
          type="text"
          name="first_name"
          placeholder="First Name"
          value={profile.first_name}
          onChange={handleChange}
        />
        <input
          type="text"
          name="last_name"
          placeholder="Last Name"
          value={profile.last_name}
          onChange={handleChange}
        />
        <input
          type="text"
          name="phone"
          placeholder="Phone Number"
          value={profile.phone}
          onChange={handleChange}
        />
        <input
          type="text"
          name="default_address"
          placeholder="Address"
          value={profile.default_address}
          onChange={handleChange}
        />
        <input
          type="text"
          name="default_city"
          placeholder="City"
          value={profile.default_city}
          onChange={handleChange}
        />
        <input
          type="text"
          name="default_state"
          placeholder="State"
          value={profile.default_state}
          onChange={handleChange}
        />
        <input
          type="text"
          name="default_pincode"
          placeholder="Pincode"
          value={profile.default_pincode}
          onChange={handleChange}
        />
        <button type="submit">Complete Profile</button>
      </form>
    </div>
  );
};

export default Profile;
